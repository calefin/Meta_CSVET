<?php
// Configurações e dados dos sites do ecossistema CSVET

// Configurações globais para SEO e Open Graph
$seo_config = [
    'base_url' => 'https://csvet.com.br',
    'site_name' => 'CSVET',
    'title_default' => 'CSVET | Portal do Ecossistema Veterinário',
    'description_default' => 'Portal de entrada e direcionamento para soluções de Medicina Veterinária, Educação, Perícia Veterinária e Gestão Genética do Prof. Dr. Atilio Sersun Calefi.',
    'keywords' => 'medicina veterinária, patologia veterinária, perícia veterinária, genética de aves, simulados veterinária, prof atilio, csvet, prof-aid, vetrank, csvet app',
    'author' => 'Prof. Dr. Atilio Sersun Calefi',
    'og_image' => 'https://csvet.com.br/img/og-image.jpg', // Ponto de partida para imagem de compartilhamento
    'locale' => 'pt_BR'
];

// Lista completa de sites com detalhes para exibição
$sites = [
    'csvet-app' => [
        'title' => 'CSVET App',
        'url' => 'https://csvet.app',
        'badge' => 'Portal Central',
        'color' => '#10b981', // Esmeralda / Verde Vet
        'description' => 'O portal central de aplicativos educacionais interativos, simulados, mentorias e cursos especializados em Medicina Veterinária, Imunologia, Patologia e Microbiologia.',
        'icon' => 'app'
    ],
    'profatilio' => [
        'title' => 'Prof. Atilio',
        'url' => 'https://profatilio.com.br',
        'badge' => 'Acadêmico & Carreira',
        'color' => '#3b82f6', // Azul
        'description' => 'Espaço acadêmico e profissional do Prof. Dr. Atilio Sersun Calefi. Conteúdos científicos, guias de carreira na veterinária, normas ABNT e materiais didáticos.',
        'icon' => 'academic'
    ],
    'vetrank' => [
        'title' => 'VetRank',
        'url' => 'https://vetrank.com.br',
        'badge' => 'Educação Gamificada',
        'color' => '#f59e0b', // Âmbar / Ouro
        'description' => 'Plataforma preparatória inteligente com bancos de questões de alta qualidade, simulados para o ENADE, residências e concursos públicos de Medicina Veterinária.',
        'icon' => 'ranking'
    ],
    'medvetlegal' => [
        'title' => 'MedVet Legal',
        'url' => 'https://medvetlegal.com.br',
        'badge' => 'Perícia Veterinária',
        'color' => '#ef4444', // Vermelho
        'description' => 'Consultoria e assessoria em perícia e assistência técnica veterinária forense. Suporte ético e técnico para advogados, clínicas, tutores de animais e o poder judiciário.',
        'icon' => 'legal'
    ],
    'plumoragen' => [
        'title' => 'Plumora Gen',
        'url' => 'https://plumoragen.com',
        'badge' => 'Gestão de Aves',
        'color' => '#8b5cf6', // Roxo / Violeta
        'description' => 'Plataforma avançada de gestão para criadores de aves (exóticas, domésticas e pombos-correio), com foco em controle genético, árvore genealógica e pedigree.',
        'icon' => 'genetic'
    ],
    'profaid' => [
        'title' => 'Prof-Aid',
        'url' => 'https://prof-aid.com',
        'badge' => 'Gestão de Provas',
        'color' => '#ec4899', // Rosa
        'description' => 'Plataforma para instituições de ensino e docentes que automatiza a criação de avaliações em PDF com múltiplas versões e realiza correção instantânea via câmera.',
        'icon' => 'exam'
    ]
];

// Mapeamento de chaves alternativas para redirecionamento rápido
$redirect_map = [
    'app'          => 'csvet-app',
    'csvet'        => 'csvet-app',
    'csvetapp'     => 'csvet-app',
    'profatilio'   => 'profatilio',
    'atilio'       => 'profatilio',
    'vetrank'      => 'vetrank',
    'medvetlegal'  => 'medvetlegal',
    'legal'        => 'medvetlegal',
    'plumoragen'   => 'plumoragen',
    'genetica'     => 'plumoragen',
    'plumora'      => 'plumoragen',
    'profaid'      => 'profaid',
    'aid'          => 'profaid'
];
