# Portal e Gateway do Ecossistema CSVET

Este é o código-fonte do portal principal do domínio **csvet.com.br**. Ele atua como um hub central moderno e de alta performance, projetado para direcionar os visitantes de forma elegante para as várias plataformas e sites do ecossistema do **Prof. Dr. Atilio Sersun Calefi**.

## 🚀 Estrutura de Arquivos

*   `index.php`: Página principal que renderiza a interface do portal (hub) e também gerencia a tela de contagem regressiva para redirecionamento.
*   `data.php`: Arquivo de configuração contendo os metadados dos sites (links, cores, descrições, tags) e mapeamento de chaves para redirecionamentos.
*   `css/style.css`: Folha de estilo contendo o design moderno, responsivo, efeitos de glassmorphism e animações.
*   `.htaccess`: Configuração do servidor Apache para permitir URLs amigáveis (ex: `csvet.com.br/vetrank`).

---

## 🎨 Funcionalidades de Design & UX

1.  **Aparência Premium (Dark Theme)**: Cores balanceadas, sombras suaves e gradientes que garantem uma experiência visual incrível.
2.  **Glassmorphism & Glow Effects**: Cartões translúcidos com bordas brilhantes que reagem ao mouse e adotam a cor característica de cada marca/site.
3.  **Micro-animações**: Ícones interativos, transições suaves e blobs decorativos flutuantes em segundo plano para dar vida à interface.
4.  **Sistema de Redirecionamento com Countdown**: Tela dedicada com contagem regressiva visual e carregador circular caso o usuário acesse por um link direto ou URL amigável.
5.  **Responsividade Total**: Experiência otimizada e testada para smartphones, tablets e desktops.

---

## ⚙️ Como Usar e Configurar

### 1. Adicionando ou Modificando Portais
Para editar links, descrições, tags ou cores de destaque das plataformas, edite o arquivo [data.php](file:///D:/csvet/data.php):

```php
'chave-do-site' => [
    'title' => 'Nome do Site',
    'url' => 'https://exemplo.com.br',
    'badge' => 'Tag/Categoria',
    'color' => '#HEX_COLOR', // Cor de destaque do card/glow
    'description' => 'Descrição detalhada do site...',
    'icon' => 'app|academic|ranking|legal|genetic|exam' // Ícones pré-definidos no index.php
]
```

### 2. Mapeamento de Redirecionamentos (Redirecionamento Rápido)
Você pode configurar apelidos rápidos no vetor `$redirect_map` do arquivo [data.php](file:///D:/csvet/data.php):

```php
$redirect_map = [
    'apelido' => 'chave-do-site' // Mapeia o apelido à chave real descrita acima
];
```

*   **Exemplo**: Acessar `csvet.com.br/genetica` ou `csvet.com.br/plumora` redirecionará o usuário automaticamente para a página do Plumora Gen (`plumoragen.com`).

### 3. Modos de Redirecionamento
*   **Com Contador Visual (Recomendado)**: Apenas chame `csvet.com.br/vetrank` ou `csvet.com.br/index.php?go=vetrank`. O usuário verá a logo da plataforma, uma descrição do que ela faz e um contador de 3 segundos antes de ser levado ao destino.
*   **Imediato (Silencioso)**: Adicione o parâmetro `direct=1` na URL, por exemplo `csvet.com.br/vetrank?direct=1` ou `csvet.com.br/index.php?go=vetrank&direct=1`. O servidor fará um redirecionamento HTTP 302 direto e instantâneo sem exibir interface gráfica.

---

## 💻 Requisitos e Instalação em Servidor

### Requisitos
*   Servidor Web (Apache com `mod_rewrite` habilitado, ou Nginx)
*   PHP 7.0 ou superior

### Hospedagem Apache (Mais comum - HostGator, Locaweb, KingHost, etc.)
Basta copiar todos os arquivos deste repositório para o diretório raiz público (`public_html`, `www` ou `htdocs`) do seu servidor. O arquivo `.htaccess` já está configurado para gerenciar as URLs amigáveis automaticamente.

### Hospedagem Nginx
Se o seu servidor utiliza Nginx, adicione a seguinte regra de reescrita nas suas configurações de bloco de servidor (`server block`) para habilitar as URLs amigáveis:

```nginx
location / {
    try_files $uri $uri/ /index.php?go=$uri&$args;
}
```
