<?php
require_once 'data.php';

// Helper para converter hex em rgba no PHP
function hex2rgba($color, $opacity) {
    $color = ltrim($color, '#');
    if (strlen($color) == 6) {
        list($r, $g, $b) = array($color[0].$color[1], $color[2].$color[3], $color[4].$color[5]);
    } elseif (strlen($color) == 3) {
        list($r, $g, $b) = array($color[0].$color[0], $color[1].$color[1], $color[2].$color[2]);
    } else {
        return "rgba(0,0,0,0)";
    }
    $r = hexdec($r);
    $g = hexdec($g);
    $b = hexdec($b);
    return "rgba($r, $g, $b, $opacity)";
}

// Helper para obter SVG
function getSvgIcon($iconName) {
    switch ($iconName) {
        case 'app':
            return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="2" y="3" width="20" height="14" rx="2" ry="2" />
                <line x1="8" y1="21" x2="16" y2="21" />
                <line x1="12" y1="17" x2="12" y2="21" />
            </svg>';
        case 'academic':
            return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M22 10v6M2 10l10-5 10 5-10 5z" />
                <path d="M6 12v5c0 2 2 3 6 3s6-1 6-3v-5" />
            </svg>';
        case 'ranking':
            return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
            </svg>';
        case 'legal':
            return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <line x1="12" y1="2" x2="12" y2="22" />
                <line x1="5" y1="7" x2="19" y2="7" />
                <path d="M19 7c0 5-3.5 8-7 8s-7-3-7-8" />
                <path d="M12 15c0 3 2.5 5 5 5h-10c2.5 0 5-2 5-5" />
            </svg>';
        case 'genetic':
            return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M4.5 10.5c3-3 6-3 9 0s6 3 9 0" />
                <path d="M4.5 13.5c3 3 6 3 9 0s6-3 9 0" />
                <line x1="8" y1="9" x2="8" y2="15" />
                <line x1="16" y1="9" x2="16" y2="15" />
                <line x1="12" y1="7.5" x2="12" y2="16.5" />
            </svg>';
        case 'exam':
            return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                <polyline points="14 2 14 8 20 8" />
                <line x1="16" y1="13" x2="8" y2="13" />
                <line x1="16" y1="17" x2="8" y2="17" />
                <polyline points="10 9 9 9 8 9" />
            </svg>';
        default:
            return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="12" r="10" />
                <line x1="12" y1="8" x2="12" y2="16" />
                <line x1="8" y1="12" x2="16" y2="12" />
            </svg>';
    }
}

// Verifica se há pedido de redirecionamento
$isRedirect = false;
$redirectSite = null;

if (isset($_GET['go'])) {
    $go = strtolower(trim($_GET['go']));
    if (isset($redirect_map[$go])) {
        $targetKey = $redirect_map[$go];
        if (isset($sites[$targetKey])) {
            $redirectSite = $sites[$targetKey];
            
            // Se for redirecionamento imediato via parâmetro direct=1
            if (isset($_GET['direct']) && $_GET['direct'] == '1') {
                header("Location: " . $redirectSite['url'], true, 302);
                exit;
            }
            
            $isRedirect = true;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- SEO Meta Tags -->
    <?php
    $pageTitle = $isRedirect 
        ? "Redirecionando para " . htmlspecialchars($redirectSite['title']) . " | " . htmlspecialchars($seo_config['site_name'])
        : htmlspecialchars($seo_config['title_default']);
        
    $pageDesc = $isRedirect 
        ? "Você está sendo redirecionado para o site " . htmlspecialchars($redirectSite['title']) . " no ecossistema " . htmlspecialchars($seo_config['site_name']) . "."
        : htmlspecialchars($seo_config['description_default']);
        
    $canonicalUrl = $seo_config['base_url'] . ($isRedirect ? "/index.php?go=" . urlencode($go) : "/");
    ?>
    <title><?php echo $pageTitle; ?></title>
    <meta name="description" content="<?php echo $pageDesc; ?>">
    <meta name="keywords" content="<?php echo htmlspecialchars($seo_config['keywords']); ?>">
    <meta name="author" content="<?php echo htmlspecialchars($seo_config['author']); ?>">
    
    <!-- Indexação controlada: evita duplicados e indexações indesejadas de rotas de redirect -->
    <?php if ($isRedirect): ?>
        <meta name="robots" content="noindex, follow">
        <meta http-equiv="refresh" content="3;url=<?php echo htmlspecialchars($redirectSite['url']); ?>">
    <?php else: ?>
        <meta name="robots" content="index, follow">
    <?php endif; ?>
    
    <link rel="canonical" href="<?php echo $canonicalUrl; ?>">
    
    <!-- Open Graph (Facebook / WhatsApp / Telegram) -->
    <meta property="og:locale" content="<?php echo htmlspecialchars($seo_config['locale']); ?>">
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?php echo $pageTitle; ?>">
    <meta property="og:description" content="<?php echo $pageDesc; ?>">
    <meta property="og:url" content="<?php echo $canonicalUrl; ?>">
    <meta property="og:site_name" content="<?php echo htmlspecialchars($seo_config['site_name']); ?>">
    <meta property="og:image" content="<?php echo htmlspecialchars($seo_config['og_image']); ?>">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    
    <!-- Twitter Cards (X) -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo $pageTitle; ?>">
    <meta name="twitter:description" content="<?php echo $pageDesc; ?>">
    <meta name="twitter:image" content="<?php echo htmlspecialchars($seo_config['og_image']); ?>">
    
    <!-- Structured Data (JSON-LD) para otimizar busca do Google -->
    <?php if (!$isRedirect): ?>
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "WebSite",
      "name": "<?php echo htmlspecialchars($seo_config['site_name']); ?>",
      "url": "<?php echo htmlspecialchars($seo_config['base_url']); ?>",
      "description": "<?php echo htmlspecialchars($seo_config['description_default']); ?>",
      "author": {
        "@type": "Person",
        "name": "<?php echo htmlspecialchars($seo_config['author']); ?>",
        "url": "https://profatilio.com.br"
      },
      "about": {
        "@type": "Thing",
        "name": "Medicina Veterinária, Educação, Perícia Veterinária e Genética de Aves"
      },
      "relatedLink": [
        <?php 
        $links = [];
        foreach ($sites as $site) {
            $links[] = '"' . $site['url'] . '"';
        }
        echo implode(",\n        ", $links);
        ?>
      ]
    }
    </script>
    <?php endif; ?>
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Outfit:wght@700;800&display=swap" rel="stylesheet">
    
    <!-- Stylesheets -->
    <link rel="stylesheet" href="css/style.css">
    
    <!-- Favicon (Fallback elegante usando SVG) -->
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220%22 width=%22100%22 height=%22100%22><text y=%220.9em%22 font-size=%2290%22>🩺</text></svg>">
</head>
<body>

    <!-- Background Blobs -->
    <div class="bg-blobs">
        <div class="blob blob-1"></div>
        <div class="blob blob-2"></div>
        <div class="blob blob-3"></div>
    </div>

    <?php if ($isRedirect && $redirectSite): 
        $themeColor = $redirectSite['color'];
        $themeColorOp10 = hex2rgba($themeColor, 0.1);
        $themeColorOp20 = hex2rgba($themeColor, 0.2);
        $themeColorOp30 = hex2rgba($themeColor, 0.3);
    ?>
        <!-- TELA DE REDIRECIONAMENTO COM COUNTDOWN -->
        <main class="container" style="display: flex; align-items: center; justify-content: center; flex-grow: 1; padding: 2rem 0;">
            <div class="redirect-container" id="redirect-element" style="--theme-color: <?php echo $themeColor; ?>; --theme-color-op10: <?php echo $themeColorOp10; ?>; --theme-color-op20: <?php echo $themeColorOp20; ?>; --theme-color-op30: <?php echo $themeColorOp30; ?>;">
                
                <div class="redirect-icon-large">
                    <?php echo getSvgIcon($redirectSite['icon']); ?>
                </div>
                
                <h1 class="redirect-title" id="redirect-heading">Redirecionando...</h1>
                <p class="redirect-subtitle" id="redirect-desc">
                    Você está sendo direcionado para o site <strong><?php echo htmlspecialchars($redirectSite['title']); ?></strong>.<br>
                    <?php echo htmlspecialchars($redirectSite['badge']); ?>
                </p>
                
                <!-- Countdown Circle Loader -->
                <div class="loader-wrapper" id="loader-wrapper-id">
                    <svg class="loader-svg" viewBox="0 0 100 100">
                        <circle class="loader-track" cx="50" cy="50" r="45"></circle>
                        <circle class="loader-bar" cx="50" cy="50" r="45"></circle>
                    </svg>
                    <div class="loader-text" id="countdown-text">3</div>
                </div>
                
                <div class="btn-group" id="btn-group-id">
                    <a href="<?php echo htmlspecialchars($redirectSite['url']); ?>" class="btn btn-primary" id="btn-go-now">
                        Ir Agora 
                        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                            <polyline points="12 5 19 12 12 19"></polyline>
                        </svg>
                    </a>
                    <a href="index.php" class="btn btn-secondary" id="btn-cancel">Voltar ao Portal</a>
                </div>
                
            </div>
        </main>
        
        <script>
            // JavaScript Countdown Timer
            let timeLeft = 3;
            const countdownText = document.getElementById('countdown-text');
            const targetUrl = "<?php echo $redirectSite['url']; ?>";
            
            const timer = setInterval(() => {
                timeLeft--;
                if (countdownText) {
                    countdownText.textContent = timeLeft;
                }
                
                if (timeLeft <= 0) {
                    clearInterval(timer);
                    window.location.href = targetUrl;
                }
            }, 1000);
        </script>

    <?php else: ?>
        
        <!-- HEADER DO PORTAL -->
        <header class="main-header container" id="main-header-id">
            <div class="logo-wrapper">
                <svg class="logo-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
                </svg>
                <div class="logo-text">CS<span>VET</span></div>
            </div>
            
            <h1 class="main-title" id="main-title-id">Hub de Soluções <span>Veterinárias e Educacionais</span></h1>
            <p class="main-subtitle" id="main-subtitle-id">
                Conectando você às plataformas de estudo, perícia, gestão genética e ferramentas acadêmicas do ecossistema do <strong>Prof. Dr. Atilio Sersun Calefi</strong>.
            </p>
        </header>

        <!-- GRID DE SITES -->
        <main class="container" style="flex-grow: 1;">
            <div class="portal-grid" id="portal-grid-id">
                <?php foreach ($sites as $key => $site): 
                    $themeColor = $site['color'];
                    $themeColorOp10 = hex2rgba($themeColor, 0.1);
                    $themeColorOp20 = hex2rgba($themeColor, 0.2);
                    $themeColorOp30 = hex2rgba($themeColor, 0.3);
                    $themeColorOp40 = hex2rgba($themeColor, 0.4);
                ?>
                    <a href="index.php?go=<?php echo $key; ?>" class="portal-card" id="card-<?php echo $key; ?>" style="--theme-color: <?php echo $themeColor; ?>; --theme-color-op10: <?php echo $themeColorOp10; ?>; --theme-color-op20: <?php echo $themeColorOp20; ?>; --theme-color-op30: <?php echo $themeColorOp30; ?>; --theme-color-op40: <?php echo $themeColorOp40; ?>;">
                        
                        <div class="card-header">
                            <div class="card-icon-container">
                                <?php echo getSvgIcon($site['icon']); ?>
                            </div>
                            <span class="badge"><?php echo htmlspecialchars($site['badge']); ?></span>
                        </div>
                        
                        <h2 class="card-title"><?php echo htmlspecialchars($site['title']); ?></h2>
                        <p class="card-description"><?php echo htmlspecialchars($site['description']); ?></p>
                        
                        <div class="card-footer">
                            <span>Acessar plataforma</span>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                <line x1="5" y1="12" x2="19" y2="12"></line>
                                <polyline points="12 5 19 12 12 19"></polyline>
                            </svg>
                        </div>
                        
                    </a>
                <?php endforeach; ?>
            </div>
        </main>

    <?php endif; ?>

    <!-- FOOTER COMPARTILHADO -->
    <footer class="main-footer" id="main-footer-id">
        <div class="container footer-content">
            <div class="social-links" id="social-links-id">
                <!-- YouTube -->
                <a href="https://www.youtube.com/@CSVET" class="social-btn" target="_blank" rel="noopener noreferrer" aria-label="YouTube CSVET" id="btn-social-yt">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19c1.72.46 8.6.46 8.6.46s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.33z" />
                        <polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02" />
                    </svg>
                </a>
                <!-- Instagram (Prof Atilio) -->
                <a href="https://www.instagram.com/prof.atilio/" class="social-btn" target="_blank" rel="noopener noreferrer" aria-label="Instagram Prof Atilio" id="btn-social-ig">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
                        <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                        <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
                    </svg>
                </a>
            </div>
            
            <p class="footer-text">
                &copy; <?php echo date('Y'); ?> <strong>CSVET</strong> - Todos os direitos reservados.<br>
                Desenvolvido e mantido pelo <a href="https://profatilio.com.br" target="_blank" rel="noopener noreferrer">Prof. Dr. Atilio Sersun Calefi</a>.
            </p>
        </div>
    </footer>

</body>
</html>
