<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog MedVetLegal | Artigos Técnicos e Notícias</title>
    <link rel="canonical" href="https://www.medvetlegal.com.br/blog.php">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">

    <link rel="icon" type="image/png" href="assets/favicon.png">
    <link rel="apple-touch-icon" href="assets/favicon.png">
    
    <style>
        /* Mesmo estilo do Index para manter identidade */
        :root { var(--primary-color: #0e2a47); var(--accent-color: #c7a006); }
        body { font-family: 'Lato', sans-serif; background-color: #f8f9fa; }
        h1, h2, h3 { font-family: 'Playfair Display', serif; }
        .navbar { background-color: #0e2a47; padding: 1rem 0; }
        .navbar-brand { font-size: 1.5rem; color: white !important; }
        .nav-link { color: rgba(255,255,255,0.8) !important; margin-left: 15px; }
        .nav-link:hover { color: #c7a006 !important; }
        
        .blog-header {
            background-color: #0e2a47;
            color: white;
            padding: 80px 0 40px;
            text-align: center;
        }
        
        .card-blog {
            border: none;
            transition: transform 0.3s;
            height: 100%;
            background: white;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }
        .card-blog:hover { transform: translateY(-5px); }
        .card-img-top { height: 200px; object-fit: cover; }
        .read-more { color: #c7a006; font-weight: bold; text-decoration: none; }
        
        footer { background-color: #0e2a47; color: white; padding: 40px 0; margin-top: 50px; }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">MEDVET LEGAL</a>
            <button class="navbar-toggler navbar-dark" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="index.php">Voltar ao Site</a></li>
                    <li class="nav-item"><a class="nav-link active" href="blog.php">Blog</a></li>
                    <li class="nav-item"><a class="nav-link btn btn-outline-light ms-3 px-3" href="index.php#contato">Contato</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <header class="blog-header">
        <div class="container">
            <h1>Artigos Técnicos & Jurisprudência</h1>
            <p class="lead">Conteúdo especializado em Medicina Veterinária Legal e Forense.</p>
        </div>
    </header>

    <div class="container py-5">
        <div class="row g-4">
            
            <div class="col-md-4">
                <div class="card card-blog">
                    <img src="assets/hero-bg.jpg" class="card-img-top" alt="Microscópio">
                    <div class="card-body d-flex flex-column">
                        <small class="text-muted mb-2">Toxicologia Forense | 02 Jan 2026</small>
                        <h4 class="card-title">Como provar intoxicação por "Chumbinho" (Carbamatos)?</h4>
                        <p class="card-text text-muted small">É possível detectar veneno após o enterro do animal? Saiba como a exumação técnica e a análise laboratorial podem fundamentar processos judiciais.</p>
                        <div class="mt-auto">
                            <a href="artigo-01.php" class="read-more">Ler Artigo Completo &rarr;</a>
                        </div>
                    </div>
                </div>
            </div>

            </div>
    </div>

    <footer>
        <div class="container text-center">
            <p class="small text-white-50 mb-0">&copy; <?php echo date("Y"); ?> MedVetLegal - Todos os direitos reservados.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>