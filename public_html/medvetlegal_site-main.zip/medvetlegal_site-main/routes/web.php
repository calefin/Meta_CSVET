<?php

use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\TicketController;
use App\Http\Controllers\Admin\PostController as AdminPostController;
use App\Http\Middleware\AdminMiddleware;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\ContactController;
use App\Http\Controllers\BlogController;

use App\Http\Controllers\ClientTicketController;

Route::get('/', function () {
    return view('welcome');
});

Route::post('/contato/enviar', [ContactController::class, 'submit'])->name('contact.submit');

Route::get('/blog', [BlogController::class, 'index'])->name('blog.index');
Route::get('/blog/{slug}', [BlogController::class, 'show'])->name('blog.show');

// Public Client Tracking Portal
Route::get('/tickets/acompanhar/{token}', [ClientTicketController::class, 'show'])->name('tickets.show_public');
Route::post('/tickets/acompanhar/{token}/mensagem', [ClientTicketController::class, 'mensagem'])->name('tickets.mensagem_public');
Route::post('/tickets/acompanhar/{token}/status', [ClientTicketController::class, 'updateStatus'])->name('tickets.status_public');

// Dynamic Sitemap
use App\Http\Controllers\SitemapController;
Route::get('/sitemap.xml', [SitemapController::class, 'index'])->name('sitemap');

// Terms of Use & LGPD Policy
Route::get('/termos', function () {
    return view('public.terms');
})->name('terms');

Auth::routes();

Route::middleware(['auth', AdminMiddleware::class])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    
    // Tickets
    Route::get('/tickets', [TicketController::class, 'index'])->name('tickets.index');
    Route::get('/tickets/create', [TicketController::class, 'create'])->name('tickets.create');
    Route::post('/tickets', [TicketController::class, 'store'])->name('tickets.store');
    Route::get('/tickets/{ticket}', [TicketController::class, 'show'])->name('tickets.show');
    Route::put('/tickets/{ticket}', [TicketController::class, 'update'])->name('tickets.update');
    Route::post('/tickets/{ticket}/mensagem', [TicketController::class, 'mensagem'])->name('tickets.mensagem');

    // Blog CRUD
    Route::resource('posts', AdminPostController::class);
});

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');