@extends('layouts.public')

@section('title', 'MedVetLegal | Perícia e Assistência Técnica Veterinária')

@section('content')

    <!-- Hero Section -->
    <header id="home" class="hero-section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10 animated fadeInUp">
                    <h1 class="hero-title">Rigor Científico na Medicina Veterinária Forense</h1>
                    <p class="hero-subtitle">
                        Pareceres técnicos, perícia judicial e assistência técnica especializada em Patologia, Toxicologia e auditoria de processos, sob a coordenação científica da perita Dra. Adriana de Siqueira.
                    </p>
                    <a href="#contato" class="btn btn-gold">
                        <i class="fas fa-file-invoice-dollar me-2"></i>Solicitar Análise de Caso
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- Specialists Section -->
    <section id="especialistas" class="section-padding bg-light">
        <div class="container">
            <div class="text-center">
                <h2 class="section-title">Corpo Técnico Especializado</h2>
                <p class="section-desc">
                    Unimos a ciência médico-veterinária forense ao direito para fornecer laudos técnicos de alta robustez probatória.
                </p>
            </div>

            <div class="row g-5 justify-content-center mt-3">
                <!-- Dra. Adriana Profile -->
                <div class="col-lg-5 col-md-6">
                    <div class="card profile-card h-100">
                        <div class="profile-header"></div>
                        <div class="card-body text-center px-4 pb-5">
                            <img src="{{ asset('assets/adriana.jpg') }}" alt="Dra. Adriana de Siqueira" class="profile-img">
                            <h3>Profa. Dra. Adriana de Siqueira</h3>
                            <div class="profile-role">Perita Principal & Coordenadora Técnica</div>
                            
                            <div class="profile-features">
                                <div class="profile-feature-item">
                                    <i class="fas fa-graduation-cap"></i>
                                    <span><strong>Doutora e Mestre em Patologia (USP):</strong> Tese de doutorado referência nacional sobre detecção de Carbamatos (chumbinho) em animais exumados.</span>
                                </div>
                                <div class="profile-feature-item">
                                    <i class="fas fa-award"></i>
                                    <span><strong>Premiada Internacionalmente:</strong> Vencedora do <em>IVFSA Student Award</em> da International Veterinary Forensic Sciences Association.</span>
                                </div>
                                <div class="profile-feature-item">
                                    <i class="fas fa-balance-scale"></i>
                                    <span><strong>Multidisciplinaridade:</strong> Graduada em Medicina Veterinária (UFPR) e Ciências Econômicas (USP).</span>
                                </div>
                                <div class="profile-feature-item">
                                    <i class="fas fa-check-double"></i>
                                    <span><strong>Atuação Especializada:</strong> Elucidação de <em>causa mortis</em>, exumação técnica e averiguação de crueldade e maus-tratos.</span>
                                </div>
                            </div>
                            
                            <div class="profile-card-footer">
                                <a href="http://lattes.cnpq.br/8627498416487640" target="_blank" class="btn btn-lattes">
                                    <i class="fas fa-file-text me-2"></i>Ver Currículo Lattes
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Dr. Atilio Profile -->
                <div class="col-lg-5 col-md-6">
                    <div class="card profile-card h-100">
                        <div class="profile-header"></div>
                        <div class="card-body text-center px-4 pb-5">
                            <img src="{{ asset('assets/atilio.jpg') }}" alt="Dr. Atilio Sersun Calefi" class="profile-img">
                            <h3>Prof. Dr. Atilio Sersun Calefi</h3>
                            <div class="profile-role">Consultor Científico Especializado</div>
                            
                            <div class="profile-features">
                                <div class="profile-feature-item">
                                    <i class="fas fa-graduation-cap"></i>
                                    <span><strong>Pós-Doutor em Farmacologia (USP):</strong> Pesquisa avançada em toxicologia veterinária e neuroimunomodulação.</span>
                                </div>
                                <div class="profile-feature-item">
                                    <i class="fas fa-microscope"></i>
                                    <span><strong>Dupla Formação Científica:</strong> Graduado em Medicina Veterinária (UEL) e Ciências Biológicas (UNICSUL).</span>
                                </div>
                                <div class="profile-feature-item">
                                    <i class="fas fa-book-reader"></i>
                                    <span><strong>Atuação Educacional:</strong> Diretor da CSVET Editora, Cursos e Treinamentos, preceptor de patologia e palestrante nacional.</span>
                                </div>
                                <div class="profile-feature-item">
                                    <i class="fas fa-vials"></i>
                                    <span><strong>Atuação Especializada:</strong> Análise crítica de exames toxicológicos complexos e consultoria farmacêutica especializada.</span>
                                </div>
                            </div>
                            
                            <div class="profile-card-footer">
                                <a href="http://lattes.cnpq.br/4438211760493798" target="_blank" class="btn btn-lattes">
                                    <i class="fas fa-file-text me-2"></i>Ver Currículo Lattes
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section id="servicos" class="section-padding">
        <div class="container">
            <div class="text-center">
                <h2 class="section-title">Áreas de Atuação</h2>
                <p class="section-desc">
                    Prestamos suporte técnico a médicos veterinários, responsáveis por animais, seguradoras, produtores rurais e escritórios de advocacia.
                </p>
            </div>

            <div class="row g-4 mt-2">
                <!-- Servico 1 -->
                <div class="col-lg-4 col-md-6">
                    <div class="service-card text-center">
                        <div class="service-icon-wrapper">
                            <i class="fas fa-skull-crossbones"></i>
                        </div>
                        <h4>Toxicologia Forense</h4>
                        <p>
                            Especialistas em laudos para suspeitas de envenenamento (como carbamatos / "chumbinho"), erro de dosagem medicamentosa e reações adversas graves. Análise crítica laboratorial.
                        </p>
                    </div>
                </div>

                <!-- Servico 2 -->
                <div class="col-lg-4 col-md-6">
                    <div class="service-card text-center">
                        <div class="service-icon-wrapper">
                            <i class="fas fa-search"></i>
                        </div>
                        <h4>Necropsia e Exumação</h4>
                        <p>
                            Acompanhamento e execução de necropsias com rígido controle de cadeia de custódia. Elaboração de pareceres sobre laudos oficiais e realização de exumações.
                        </p>
                    </div>
                </div>

                <!-- Servico 3 -->
                <div class="col-lg-4 col-md-6">
                    <div class="service-card text-center">
                        <div class="service-icon-wrapper">
                            <i class="fas fa-gavel"></i>
                        </div>
                        <h4>Assistência Técnica Judicial</h4>
                        <p>
                            Formulação de quesitos periciais, acompanhamento presencial de diligências, assistência na redação de petições técnicas e contestação de laudos periciais desfavoráveis.
                        </p>
                    </div>
                </div>

                <!-- Servico 4 -->
                <div class="col-lg-4 col-md-6">
                    <div class="service-card text-center">
                        <div class="service-icon-wrapper">
                            <i class="fas fa-file-medical-alt"></i>
                        </div>
                        <h4>Auditoria de Erro Veterinário</h4>
                        <p>
                            Análise crítica detalhada de prontuários, termos de consentimento, receitas e prontuários clínicos para avaliação de nexo causal e conformidade ética e técnica.
                        </p>
                    </div>
                </div>

                <!-- Servico 5 -->
                <div class="col-lg-4 col-md-6">
                    <div class="service-card text-center">
                        <div class="service-icon-wrapper">
                            <i class="fas fa-paw"></i>
                        </div>
                        <h4>Maus-tratos e Bem-estar</h4>
                        <p>
                            Emissão de laudos periciais caracterizando a ocorrência de maus-tratos físicos, psicológicos, negligência de cuidados ou colecionismo de animais (Síndrome de Noé).
                        </p>
                    </div>
                </div>

                <!-- Servico 6 -->
                <div class="col-lg-4 col-md-6">
                    <div class="service-card text-center">
                        <div class="service-icon-wrapper">
                            <i class="fas fa-graduation-cap"></i>
                        </div>
                        <h4>Cursos e Treinamentos</h4>
                        <p>
                            Palestras e capacitações corporativas sobre responsabilidade civil do médico veterinário, gestão de risco legal para hospitais e procedimentos periciais forenses.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact & Quote Request Section -->
    <section id="contato" class="section-padding contact-section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-10">
                    <div class="card contact-card">
                        <div class="row g-0">
                            <!-- Info Panel -->
                            <div class="col-lg-5 contact-info-panel">
                                <h3>Fale com a Perita Principal</h3>
                                <p class="mb-5 opacity-75">
                                    Preencha o formulário para submeter seu caso diretamente para a avaliação de viabilidade técnica da Dra. Adriana de Siqueira. Asseguramos sigilo absoluto.
                                </p>
                                
                                <div class="contact-info-item">
                                    <div class="contact-info-icon">
                                        <i class="fas fa-envelope"></i>
                                    </div>
                                    <div class="contact-info-text">
                                        <h5>E-mail Direto da Perita</h5>
                                        <a href="mailto:patoforense.adriana@gmail.com">patoforense.adriana@gmail.com</a>
                                    </div>
                                </div>
                                
                                <div class="contact-info-item">
                                    <div class="contact-info-icon">
                                        <i class="fas fa-map-marker-alt"></i>
                                    </div>
                                    <div class="contact-info-text">
                                        <h5>Abrangência</h5>
                                        <p>Base em São Paulo / SP - Atendimento presencial e remoto em todo o Brasil.</p>
                                    </div>
                                </div>

                                <div class="contact-info-item">
                                    <div class="contact-info-icon">
                                        <i class="fas fa-lock"></i>
                                    </div>
                                    <div class="contact-info-text">
                                        <h5>Sigilo</h5>
                                        <p>Todas as comunicações e documentos enviados são protegidos por estrito segredo profissional.</p>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Form Panel -->
                            <div class="col-lg-7 contact-form-panel">
                                <h3>Solicitação à Dra. Adriana</h3>
                                <p class="text-muted mb-4">Sua descrição do caso e dúvidas serão analisadas diretamente pela perita responsável.</p>
                                
                                @if(session('success'))
                                    <div class="alert alert-success">
                                        {{ session('success') }}
                                    </div>
                                @endif

                                @if($errors->any())
                                    <div class="alert alert-danger">
                                        <ul class="mb-0">
                                            @foreach($errors->all() as $error)
                                                <li>{{ $error }}</li>
                                            @endforeach
                                        </ul>
                                    </div>
                                @endif

                                <form action="{{ route('contact.submit') }}" method="POST">
                                    @csrf
                                    
                                    <!-- Honeypot anti-spam -->
                                    <div class="d-none">
                                        <label>Se você não é um robô, deixe em branco:</label>
                                        <input type="text" name="url_spam_check" tabindex="-1" autocomplete="off">
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="nome" class="form-label">Nome Completo *</label>
                                            <input type="text" class="form-control" id="nome" name="nome" value="{{ old('nome') }}" required placeholder="Seu nome">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="telefone" class="form-label">Telefone / WhatsApp *</label>
                                            <input type="tel" class="form-control" id="telefone" name="telefone" value="{{ old('telefone') }}" required placeholder="(XX) 99999-9999">
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="email" class="form-label">E-mail Profissional *</label>
                                        <input type="email" class="form-control" id="email" name="email" value="{{ old('email') }}" required placeholder="exemplo@dominio.com">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="assunto" class="form-label">Assunto / Tipo de Serviço *</label>
                                        <select class="form-select" id="assunto" name="assunto">
                                            <option value="Assistência Técnica Judicial" {{ old('assunto') == 'Assistência Técnica Judicial' ? 'selected' : '' }}>Assistência Técnica Judicial</option>
                                            <option value="Análise de Viabilidade Técnica" {{ old('assunto') == 'Análise de Viabilidade Técnica' ? 'selected' : '' }}>Análise de Viabilidade Técnica (Estudo de Caso)</option>
                                            <option value="Parecer Técnico em Prontuário" {{ old('assunto') == 'Parecer Técnico em Prontuário' ? 'selected' : '' }}>Parecer Técnico / Auditoria de Prontuário Clínico</option>
                                            <option value="Necropsia Forense ou Exumação" {{ old('assunto') == 'Necropsia Forense ou Exumação' ? 'selected' : '' }}>Necropsia Forense ou Exumação</option>
                                            <option value="Discussão de Casos de Intoxicação" {{ old('assunto') == 'Discussão de Casos de Intoxicação' ? 'selected' : '' }}>Discussão de Casos de Intoxicação (Toxicologia Forense)</option>
                                            <option value="Não sei o que preciso / Orientação" {{ old('assunto') == 'Não sei o que preciso / Orientação' ? 'selected' : '' }}>Não sei o que preciso / Quero orientação preliminar</option>
                                        </select>
                                        <span class="form-text text-muted small mt-1 d-block">
                                            <i class="fas fa-question-circle me-1"></i> Não tem certeza sobre qual serviço escolher? 
                                            <a href="{{ route('blog.show', 'diferenca-pericia-assistencia-tecnica-laudo-veterinario') }}" target="_blank" class="fw-bold" style="color: var(--accent-color);">
                                                Leia nosso guia sobre Perícia, Assistência e Laudo.
                                            </a>
                                        </span>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label for="mensagem" class="form-label">Breve relato do caso *</label>
                                        <textarea class="form-control" id="mensagem" name="mensagem" rows="4" required placeholder="Descreva o ocorrido de forma resumida...">{{ old('mensagem') }}</textarea>
                                        <span class="form-text text-muted small mt-1 d-block">
                                            <i class="fas fa-lock me-1"></i> <strong>Aviso de Privacidade:</strong> Não envie senhas, CPFs ou dados pessoais sensíveis neste relato. Se você possui documentos (exames, fotos ou processos em PDF), poderá anexá-los com segurança no seu portal de acompanhamento criptografado imediatamente após o envio deste formulário.
                                        </span>
                                    </div>

                                    <!-- Math security challenge -->
                                    <div class="mb-4">
                                        <label for="desafio_humano" class="form-label">Verificação de Segurança *</label>
                                        <input type="text" class="form-control" id="desafio_humano" name="desafio_humano" required placeholder="Quanto é 3 + 4? (Digite apenas o número)">
                                        <span class="form-text text-muted small">Proteção básica contra robôs de spam.</span>
                                    </div>
                                    
                                    <div class="d-grid">
                                        <button type="submit" class="btn btn-gold py-3">
                                            <i class="fas fa-paper-plane me-2"></i>Enviar Solicitação
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

@push('seo_schemas')
<script type="application/ld+json">
{
  "@@context": "https://schema.org",
  "@@type": "MedicalBusiness",
  "name": "MedVetLegal",
  "alternateName": "Perícias e Assistência Técnica Veterinária Forense",
  "url": "{{ url('/') }}",
  "logo": "{{ asset('assets/favicon.png') }}",
  "image": "{{ asset('assets/hero-bg.jpg') }}",
  "description": "Assistência técnica judicial e perícia veterinária forense sob a coordenação técnica da Dra. Adriana de Siqueira e consultoria do Dr. Atilio S. Calefi.",
  "telephone": "contato@medvetlegal.com.br",
  "email": "contato@medvetlegal.com.br",
  "address": {
    "@@type": "PostalAddress",
    "addressLocality": "São Paulo",
    "addressRegion": "SP",
    "addressCountry": "BR"
  },
  "geo": {
    "@@type": "GeoCoordinates",
    "latitude": "-23.550520",
    "longitude": "-46.633308"
  },
  "founder": [
    {
      "@@type": "Person",
      "name": "Dra. Adriana de Siqueira",
      "jobTitle": "Patologista Forense e Perita Principal",
      "alumniOf": "Universidade de São Paulo"
    },
    {
      "@@type": "Person",
      "name": "Dr. Atilio Sersun Calefi",
      "jobTitle": "Farmacologista Veterinário e Consultor Científico",
      "alumniOf": "Universidade de São Paulo"
    }
  ],
  "knowsAbout": [
    "Patologia Forense Veterinária",
    "Toxicologia de Carbamatos",
    "Necropsia de Cães e Gatos",
    "Exumação Técnica Animal",
    "Assistência Técnica Judicial Veterinária",
    "Erro Médico Veterinário",
    "Maus-tratos a Animais"
  ]
}
</script>
@endpush

@endsection