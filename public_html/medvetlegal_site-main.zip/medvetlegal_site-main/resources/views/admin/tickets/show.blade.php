@extends('layouts.admin')

@section('title', 'Ticket #' . $ticket->id)
@section('header')
    <h1>Ticket #{{ $ticket->id }} <a href="{{ route('admin.tickets.index') }}" class="btn btn-secondary btn-sm float-right"><i class="fas fa-arrow-left"></i> Voltar</a></h1>
@endsection

@section('content')
<div class="row">
    <div class="col-md-8">
        <!-- Mensagens -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">{{ $ticket->titulo }}</h3>
            </div>
            <div class="card-body" style="max-height: 500px; overflow-y: auto;">
                @foreach($ticket->mensagens as $msg)
                <div class="mb-3 p-3 {{ $msg->enviado_por_admin ? 'bg-light' : 'bg-info-light' }}" style="border-radius: 10px;">
                    <strong>{{ $msg->enviado_por_admin ? 'Admin' : $ticket->cliente->nome }}</strong>
                    <small class="text-muted float-right">{{ $msg->created_at->format('d/m/Y H:i') }}</small>
                    <p class="mt-2">{{ $msg->conteudo }}</p>
                    @if($msg->anexo)
                        <a href="{{ asset('storage/' . $msg->anexo) }}" target="_blank" class="btn btn-sm btn-outline-primary">
                            <i class="fas fa-file-pdf"></i> Ver Anexo
                        </a>
                    @endif
                </div>
                @endforeach
            </div>
            <div class="card-footer">
                <form action="{{ route('admin.tickets.mensagem', $ticket) }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="form-group">
                        <textarea name="conteudo" class="form-control" rows="3" placeholder="Digite sua resposta..." required></textarea>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Anexar PDF</label>
                                <input type="file" name="anexo" class="form-control-file" accept=".pdf">
                            </div>
                        </div>
                        <div class="col-md-6 text-right">
                            <button type="submit" class="btn btn-primary mt-4"><i class="fas fa-paper-plane"></i> Enviar Resposta</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <!-- Informações do Ticket -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Informações</h3>
            </div>
            <div class="card-body">
                <form action="{{ route('admin.tickets.update', $ticket) }}" method="POST">
                    @csrf
                    @method('PUT')
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status" class="form-control">
                            <option value="novo" {{ $ticket->status == 'novo' ? 'selected' : '' }}>Novo</option>
                            <option value="analise" {{ $ticket->status == 'analise' ? 'selected' : '' }}>Em Análise</option>
                            <option value="orcado" {{ $ticket->status == 'orcado' ? 'selected' : '' }}>Orçado</option>
                            <option value="aceito" {{ $ticket->status == 'aceito' ? 'selected' : '' }}>Aceito</option>
                            <option value="recusado" {{ $ticket->status == 'recusado' ? 'selected' : '' }}>Recusado</option>
                            <option value="fechado" {{ $ticket->status == 'fechado' ? 'selected' : '' }}>Fechado</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Prioridade</label>
                        <select name="prioridade" class="form-control">
                            <option value="baixa" {{ $ticket->prioridade == 'baixa' ? 'selected' : '' }}>Baixa</option>
                            <option value="media" {{ $ticket->prioridade == 'media' ? 'selected' : '' }}>Média</option>
                            <option value="alta" {{ $ticket->prioridade == 'alta' ? 'selected' : '' }}>Alta</option>
                            <option value="urgente" {{ $ticket->prioridade == 'urgente' ? 'selected' : '' }}>Urgente</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Valor Orçado (R$)</label>
                        <input type="number" name="valor_orcado" class="form-control" step="0.01" value="{{ $ticket->valor_orcado }}">
                    </div>
                    <button type="submit" class="btn btn-success btn-block"><i class="fas fa-save"></i> Atualizar</button>
                </form>
            </div>
        </div>
        
        <!-- Dados do Cliente -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Cliente</h3>
            </div>
            <div class="card-body">
                <p><strong>Nome:</strong> {{ $ticket->cliente->nome }}</p>
                <p><strong>Email:</strong> {{ $ticket->cliente->email }}</p>
                <p><strong>Telefone:</strong> {{ $ticket->cliente->telefone ?? 'Não informado' }}</p>
                <p><strong>CPF/CNPJ:</strong> {{ $ticket->cliente->cpf_cnpj ?? 'Não informado' }}</p>
            </div>
        </div>
    </div>
</div>
@endsection