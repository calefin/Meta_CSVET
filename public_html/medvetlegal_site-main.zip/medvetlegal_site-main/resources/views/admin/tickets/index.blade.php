@extends('layouts.admin')

@section('title', 'Tickets')
@section('header')
    <h1>Tickets <a href="{{ route('admin.tickets.create') }}" class="btn btn-primary btn-sm float-right"><i class="fas fa-plus"></i> Novo Ticket</a></h1>
@endsection

@section('content')
<div class="card">
    <div class="card-body table-responsive p-0">
        <table class="table table-hover text-nowrap">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Cliente</th>
                    <th>Título</th>
                    <th>Status</th>
                    <th>Prioridade</th>
                    <th>Valor</th>
                    <th>Data</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                @foreach($tickets as $ticket)
                <tr>
                    <td>{{ $ticket->id }}</td>
                    <td>{{ $ticket->cliente->nome }}</td>
                    <td>{{ Str::limit($ticket->titulo, 40) }}</td>
                    <td>
                        <span class="badge badge-{{ 
                            $ticket->status == 'novo' ? 'info' : 
                            ($ticket->status == 'analise' ? 'warning' : 
                            ($ticket->status == 'orcado' ? 'primary' : 
                            ($ticket->status == 'aceito' ? 'success' : 
                            ($ticket->status == 'recusado' ? 'danger' : 'secondary')))) 
                        }}">
                            {{ ucfirst($ticket->status) }}
                        </span>
                    </td>
                    <td>
                        <span class="badge badge-{{ 
                            $ticket->prioridade == 'urgente' ? 'danger' : 
                            ($ticket->prioridade == 'alta' ? 'warning' : 
                            ($ticket->prioridade == 'media' ? 'info' : 'success')) 
                        }}">
                            {{ ucfirst($ticket->prioridade) }}
                        </span>
                    </td>
                    <td>{{ $ticket->valor_orcado ? 'R$ ' . number_format($ticket->valor_orcado, 2, ',', '.') : '-' }}</td>
                    <td>{{ $ticket->created_at->format('d/m/Y H:i') }}</td>
                    <td>
                        <a href="{{ route('admin.tickets.show', $ticket) }}" class="btn btn-sm btn-info"><i class="fas fa-eye"></i></a>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    <div class="card-footer">
        {{ $tickets->links() }}
    </div>
</div>
@endsection