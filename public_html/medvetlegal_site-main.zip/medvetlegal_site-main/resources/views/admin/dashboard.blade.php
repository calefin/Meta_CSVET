@extends('layouts.admin')

@section('title', 'Dashboard')

@section('header')
    <h1>Dashboard</h1>
@endsection

@section('content')
<div class="row">
    <div class="col-lg-3 col-6">
        <div class="small-box bg-info">
            <div class="inner">
                <h3>0</h3>
                <p>Tickets</p>
            </div>
            <div class="icon"><i class="fas fa-ticket-alt"></i></div>
            <a href="{{ route('admin.tickets.index') }}" class="small-box-footer">Ver todos <i class="fas fa-arrow-circle-right"></i></a>
        </div>
    </div>
    
    <div class="col-lg-3 col-6">
        <div class="small-box bg-success">
            <div class="inner">
                <h3>0</h3>
                <p>Artigos</p>
            </div>
            <div class="icon"><i class="fas fa-newspaper"></i></div>
            <a href="#" class="small-box-footer">Em breve <i class="fas fa-arrow-circle-right"></i></a>
        </div>
    </div>
    
    <div class="col-lg-3 col-6">
        <div class="small-box bg-warning">
            <div class="inner">
                <h3>0</h3>
                <p>Cursos</p>
            </div>
            <div class="icon"><i class="fas fa-graduation-cap"></i></div>
            <a href="#" class="small-box-footer">Em breve <i class="fas fa-arrow-circle-right"></i></a>
        </div>
    </div>
</div>
@endsection