<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="@yield('meta_description', 'Assistência Técnica e Perícia Veterinária Forense. Especializados em Patologia, Toxicologia (Carbamatos/Aldicarbe), Necropsia e Análise de Processos.')">
    <meta name="keywords" content="Perícia Veterinária, Medicina Legal, Necropsia Forense, Toxicologia Veterinária, Erro Médico Veterinário, Adriana de Siqueira, Atilio Calefi, Laudo Pericial, CSVET">
    <meta name="author" content="MedVetLegal">
    
    <title>@yield('title', 'MedVetLegal | Perícia e Assistência Técnica Veterinária')</title>
    
    <link rel="canonical" href="{{ url()->current() }}">
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="{{ asset('assets/favicon.png') }}">
    <link rel="apple-touch-icon" href="{{ asset('assets/favicon.png') }}">
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome 6 for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    
    <!-- Custom Style -->
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
    
    @stack('styles')
    @stack('seo_schemas')
</head>
<body>

    <!-- Header Navigation -->
    <nav class="navbar navbar-expand-lg navbar-custom sticky-top">
        <div class="container">
            <a class="navbar-brand" href="{{ url('/') }}">
                <img src="{{ asset('assets/favicon.png') }}" alt="Logo MedVetLegal" height="40" class="d-inline-block align-middle me-2" style="border-radius: 4px; background-color: rgba(255,255,255,0.9); padding: 2px;">
                <span class="brand-title">MEDVET LEGAL</span>
            </a>
            <button class="navbar-toggler navbar-dark" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav align-items-center">
                    <li class="nav-item">
                        <a class="nav-link {{ Request::is('/') ? 'active' : '' }}" href="{{ url('/') }}#home">Início</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url('/') }}#especialistas">Corpo Técnico</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url('/') }}#servicos">Atuação</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ url('/blog') }}">Blog</a>
                    </li>
                    @auth
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('admin.dashboard') }}">Painel Admin</a>
                        </li>
                    @else
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('login') }}">Login</a>
                        </li>
                    @endauth
                    <li class="nav-item ms-lg-3">
                        <a class="nav-link btn-nav-contact" href="{{ url('/') }}#contato">Fale Conosco</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content Yield -->
    <main>
        @yield('content')
    </main>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="row gy-5">
                <div class="col-lg-4 col-md-6">
                    <h5 class="brand-title">
                        <img src="{{ asset('assets/favicon.png') }}" alt="Logo MedVetLegal" height="35" class="d-inline-block align-middle me-2" style="border-radius: 4px; background-color: rgba(255,255,255,0.9); padding: 2px;">
                        MEDVET LEGAL
                    </h5>
                    <p class="mt-3">
                        Excelência técnica e ética na Medicina Veterinária Legal. Prestamos suporte altamente especializado para advogados, tutores de animais, clínicas veterinárias, indústrias e órgãos do judiciário em todo o território nacional.
                    </p>
                    <div class="footer-social-links">
                        <a href="https://www.youtube.com/@csvet" target="_blank" class="footer-social-btn"><i class="fab fa-youtube"></i></a>
                        <a href="https://www.instagram.com/atiliocalefi" target="_blank" class="footer-social-btn"><i class="fab fa-instagram"></i></a>
                        <a href="mailto:contato@medvetlegal.com.br" class="footer-social-btn"><i class="fas fa-envelope"></i></a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <h5>Links Rápidos</h5>
                    <ul class="footer-links-list mt-3">
                        <li><a href="{{ url('/') }}#home"><i class="fas fa-chevron-right me-2"></i>Início</a></li>
                        <li><a href="{{ url('/') }}#especialistas"><i class="fas fa-chevron-right me-2"></i>Corpo Técnico</a></li>
                        <li><a href="{{ url('/') }}#servicos"><i class="fas fa-chevron-right me-2"></i>Áreas de Atuação</a></li>
                        <li><a href="{{ url('/blog') }}"><i class="fas fa-chevron-right me-2"></i>Artigos Técnicos (Blog)</a></li>
                        <li><a href="{{ route('terms') }}"><i class="fas fa-chevron-right me-2"></i>Termos de Uso & LGPD</a></li>
                        <li><a href="{{ route('login') }}"><i class="fas fa-chevron-right me-2"></i>Área Restrita (Login)</a></li>
                    </ul>
                </div>
                <div class="col-lg-4 col-md-12">
                    <h5>Contato & Localização</h5>
                    <ul class="footer-links-list mt-3">
                        <li>
                            <span class="d-block text-white"><i class="fas fa-envelope text-warning me-2"></i> E-mail Geral:</span>
                            <a href="mailto:contato@medvetlegal.com.br" class="d-block py-1">contato@medvetlegal.com.br</a>
                        </li>
                        <li>
                            <span class="d-block text-white"><i class="fas fa-envelope text-warning me-2"></i> Dra. Adriana de Siqueira:</span>
                            <a href="mailto:patoforense.adriana@gmail.com" class="d-block py-1">patoforense.adriana@gmail.com</a>
                        </li>
                        <li>
                            <span class="d-block text-white"><i class="fas fa-envelope text-warning me-2"></i> Dr. Atilio S. Calefi:</span>
                            <a href="mailto:calefi@csvet.com.br" class="d-block py-1">calefi@csvet.com.br</a>
                        </li>
                        <li>
                            <span class="d-block text-white"><i class="fas fa-map-marker-alt text-warning me-2"></i> Atendimento:</span>
                            <span class="d-block small mt-1">São Paulo - SP, Brasil (Atuação Nacional)</span>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="copyright-bar">
                <p class="mb-0">&copy; {{ date('Y') }} MedVetLegal. Todos os direitos reservados. CSVET Editora, Cursos e Treinamentos.</p>
            </div>
        </div>
    </footer>

    <!-- Bootstrap 5 Bundle JS (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    @stack('scripts')
</body>
</html>
