<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ticket extends Model
{
    use HasFactory;

    protected $fillable = [
        'cliente_id',
        'titulo',
        'descricao',
        'status',
        'prioridade',
        'valor_orcado',
        'token',
    ];

    public function cliente()
    {
        return $this->belongsTo(Cliente::class);
    }

    public function mensagens()
    {
        return $this->hasMany(Mensagem::class)->orderBy('created_at', 'asc');
    }

    public function ultimaMensagem()
    {
        return $this->hasOne(Mensagem::class)->latestOfMany();
    }
}