<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Cliente;
use App\Models\Mensagem;
use App\Models\Ticket;
use Illuminate\Http\Request;

class TicketController extends Controller
{
    public function index()
    {
        $tickets = Ticket::with('cliente', 'ultimaMensagem')
            ->orderBy('created_at', 'desc')
            ->paginate(20);
        
        return view('admin.tickets.index', compact('tickets'));
    }

    public function create()
    {
        return view('admin.tickets.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'nome' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'telefone' => 'nullable|string|max:20',
            'cpf_cnpj' => 'nullable|string|max:20',
            'titulo' => 'required|string|max:255',
            'descricao' => 'required|string',
            'prioridade' => 'required|in:baixa,media,alta,urgente',
        ]);

        // Criar ou encontrar cliente
        $cliente = Cliente::firstOrCreate(
            ['email' => $validated['email']],
            [
                'nome' => $validated['nome'],
                'telefone' => $validated['telefone'] ?? null,
                'cpf_cnpj' => $validated['cpf_cnpj'] ?? null,
            ]
        );

        // Criar ticket
        $ticket = Ticket::create([
            'cliente_id' => $cliente->id,
            'titulo' => $validated['titulo'],
            'descricao' => $validated['descricao'],
            'prioridade' => $validated['prioridade'],
            'status' => 'novo',
        ]);

        // Criar primeira mensagem com a descrição
        Mensagem::create([
            'ticket_id' => $ticket->id,
            'conteudo' => $validated['descricao'],
            'enviado_por_admin' => false,
        ]);

        return redirect()->route('admin.tickets.show', $ticket)
            ->with('success', 'Ticket #' . $ticket->id . ' criado com sucesso!');
    }

    public function show(Ticket $ticket)
    {
        $ticket->load('cliente', 'mensagens.user');
        return view('admin.tickets.show', compact('ticket'));
    }

    public function update(Request $request, Ticket $ticket)
    {
        $validated = $request->validate([
            'status' => 'required|in:novo,analise,orcado,aceito,recusado,fechado',
            'prioridade' => 'required|in:baixa,media,alta,urgente',
            'valor_orcado' => 'nullable|numeric|min:0',
        ]);

        $ticket->update($validated);

        return back()->with('success', 'Ticket atualizado!');
    }

    public function mensagem(Request $request, Ticket $ticket)
    {
        $validated = $request->validate([
            'conteudo' => 'required|string',
            'anexo' => 'nullable|file|mimes:pdf|max:10240',
        ]);

        $mensagem = new Mensagem([
            'ticket_id' => $ticket->id,
            'user_id' => auth()->id(),
            'conteudo' => $validated['conteudo'],
            'enviado_por_admin' => true,
        ]);

        if ($request->hasFile('anexo')) {
            $path = $request->file('anexo')->store('anexos', 'public');
            $mensagem->anexo = $path;
        }

        $mensagem->save();

        // Disparar e-mail para o cliente
        // Mail::to($ticket->cliente->email)->send(new \App\Mail\TicketResposta($ticket, $mensagem));

        return back()->with('success', 'Resposta enviada!');
    }
}