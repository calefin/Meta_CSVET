<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Response;

class SitemapController extends Controller
{
    /**
     * Generate dynamic XML sitemap.
     */
    public function index()
    {
        $posts = Post::published()->orderBy('updated_at', 'desc')->get();

        $content = view('sitemap', compact('posts'))->render();

        return response($content, 200)
            ->header('Content-Type', 'text/xml');
    }
}
