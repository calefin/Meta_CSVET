<?php

namespace App\Http\Controllers;

use App\Models\Cliente;
use App\Models\Ticket;
use App\Models\Mensagem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class ContactController extends Controller
{
    public function submit(Request $request)
    {
        // 1. Honeypot anti-spam check
        if ($request->filled('url_spam_check')) {
            // Silent drop for bots
            return redirect()->back()->with('success', 'Sua mensagem foi enviada com sucesso!');
        }

        // 2. Math security challenge check (3 + 4 = 7)
        if (trim($request->desafio_humano) !== '7') {
            return redirect()->back()
                ->withInput()
                ->withErrors(['desafio_humano' => 'O resultado da verificação de segurança (3 + 4) está incorreto.']);
        }

        // 3. Validation
        $request->validate([
            'nome' => 'required|string|max:255',
            'telefone' => 'required|string|max:50',
            'email' => 'required|email|max:255',
            'assunto' => 'required|string',
            'mensagem' => 'required|string',
        ]);

        // 4. Create or update Cliente
        $cliente = Cliente::firstOrCreate(
            ['email' => $request->email],
            [
                'nome' => $request->nome,
                'telefone' => $request->telefone,
            ]
        );

        // Update name or phone if different
        if ($cliente->nome !== $request->nome || $cliente->telefone !== $request->telefone) {
            $cliente->update([
                'nome' => $request->nome,
                'telefone' => $request->telefone,
            ]);
        }

        // 5. Determine priority based on urgency of subject
        $prioridade = 'media';
        if ($request->assunto === 'Necropsia Forense ou Exumação') {
            $prioridade = 'urgente'; // Decomposition/forensic chain of custody is highly time-sensitive
        } elseif (in_array($request->assunto, ['Discussão de Casos de Intoxicação', 'Assistência Técnica Judicial', 'Parecer Técnico em Prontuário'])) {
            $prioridade = 'alta';
        }

        // 6. Create the Ticket (keeping the client's name out of the title for privacy)
        $ticket = Ticket::create([
            'cliente_id' => $cliente->id,
            'titulo' => $request->assunto,
            'descricao' => $request->mensagem,
            'status' => 'novo',
            'prioridade' => $prioridade,
            'token' => \Illuminate\Support\Str::random(32),
        ]);

        // 7. Create the Ticket Message
        Mensagem::create([
            'ticket_id' => $ticket->id,
            'user_id' => null, // null indicates sent by client
            'conteudo' => $request->mensagem,
            'enviado_por_admin' => false,
        ]);

        // 8. Prepare and send email notification
        $para_principal = 'patoforense.adriana@gmail.com';
        $para_copia1 = 'contato@medvetlegal.com.br';
        $para_copia2 = 'calefi@csvet.com.br';
        
        $subject = "Novo Contato MedVetLegal: {$request->assunto} - {$request->nome}";
        
        $body = "
        <html>
        <head>
          <title>Novo Contato via Site</title>
        </head>
        <body style='font-family: Arial, sans-serif; color: #333;'>
          <h2 style='color: #0e2a47;'>Novo contato recebido pelo site MedVetLegal (Ticket #{$ticket->id})</h2>
          <p><strong>Nome do Cliente:</strong> {$request->nome}</p>
          <p><strong>E-mail:</strong> {$request->email}</p>
          <p><strong>Telefone:</strong> {$request->telefone}</p>
          <p><strong>Área de Interesse:</strong> {$request->assunto}</p>
          <p><strong>Prioridade Definida:</strong> " . strtoupper($prioridade) . "</p>
          <hr style='border: 0; border-top: 1px solid #eee;'>
          <p><strong>Mensagem / Relato do Caso:</strong><br>" . nl2br(e($request->mensagem)) . "</p>
          <hr style='border: 0; border-top: 1px solid #eee;'>
          <p>
            <a href='" . url("/admin/tickets/{$ticket->id}") . "' style='background-color: #0e2a47; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px; display: inline-block; font-weight: bold; margin-right: 10px;'>
              Visualizar no Painel Administrativo
            </a>
            <a href='" . url("/tickets/acompanhar/{$ticket->token}") . "' style='background-color: #c7a006; color: #0e2a47; padding: 10px 20px; text-decoration: none; border-radius: 4px; display: inline-block; font-weight: bold;'>
              Ver Link do Cliente
            </a>
          </p>
          <p><small>Enviado em: " . date("d/m/Y H:i") . "</small></p>
        </body>
        </html>
        ";

        try {
            Mail::html($body, function ($message) use ($para_principal, $para_copia1, $para_copia2, $subject, $request) {
                $message->to($para_principal)
                        ->cc([$para_copia1, $para_copia2])
                        ->subject($subject)
                        ->replyTo($request->email);
            });
        } catch (\Exception $e) {
            // Log mail exception but do not block success redirect
            logger()->error('Falha no envio de e-mail de contato: ' . $e->getMessage());
        }

        return redirect()->back()->with('success', 'Sua solicitação de análise de caso foi recebida com sucesso! A Dra. Adriana de Siqueira analisará as informações e entrará em contato em breve.');
    }
}
