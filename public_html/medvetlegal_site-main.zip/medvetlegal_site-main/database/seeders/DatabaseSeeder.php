<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Post;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Avoid duplicate seeding errors if run multiple times
        $user = User::where('email', 'ascalefi@gmail.com')->first();
        if (!$user) {
            $user = User::create([
                'name' => 'Calefin',
                'email' => 'ascalefi@gmail.com',
                'password' => bcrypt('041188As'),
                'is_admin' => true,
            ]);
        }

        // Seed initial article
        Post::updateOrCreate(
            ['slug' => 'como-comprovar-intoxicacao-por-chumbinho-carbamatos-processos-judiciais'],
            [
                'title' => 'Como comprovar intoxicação por "Chumbinho" (Carbamatos) em processos judiciais?',
                'summary' => 'A intoxicação por praguicidas, popularmente conhecidos como "chumbinho", infelizmente ainda é uma causa comum de óbito. Em disputas judiciais, a materialidade da prova é essencial. Saiba como a exumação técnica fundamenta processos judiciais.',
                'category' => 'Toxicologia Forense',
                'image' => 'assets/hero-bg.jpg',
                'author_id' => $user->id,
                'content' => '<p class="lead">A intoxicação por praguicidas, popularmente conhecidos como "chumbinho" (principalmente o <strong>Aldicarbe</strong> e o <strong>Carbofurano</strong>), infelizmente ainda é uma causa comum de óbito em cães e gatos no Brasil. Em disputas judiciais, a materialidade da prova é essencial.</p>

<p>Muitas vezes, o animal chega ao óbito e é enterrado sem a devida análise toxicológica imediata. Nesses casos, surge a dúvida comum entre advogados e tutores: <em>ainda é possível comprovar o envenenamento após o enterro?</em></p>

<h3 class="mt-4">O Desafio da Prova Pericial</h3>
<p>Estudos científicos conduzidos por nossa equipe técnica demonstraram que a resposta é <strong>sim</strong>, mas depende de rigor técnico absoluto. Em nossa tese de doutorado pela USP, investigamos especificamente a estabilidade desses compostos em cadáveres.</p>

<h3 class="mt-4">A Importância da Exumação Técnica</h3>
<p>Nossas pesquisas revelaram que é possível detectar resíduos desses carbamatos mesmo após períodos de sepultamento. No entanto, a análise patológica e toxicológica deve considerar:</p>

<ul class="list-group list-group-flush my-4">
    <li class="list-group-item bg-transparent px-0"><strong>1. Decomposição:</strong> O tempo de enterro influencia a degradação das substâncias, exigindo métodos de correção analítica.</li>
    <li class="list-group-item bg-transparent px-0"><strong>2. Matriz Biológica:</strong> A escolha correta do material a ser coletado (fígado, conteúdo estomacal, pelos) é crítica para o sucesso da detecção.</li>
    <li class="list-group-item bg-transparent px-0"><strong>3. Cadeia de Custódia:</strong> A exumação deve seguir protocolos estritos para evitar contaminação do solo e questionamentos da defesa.</li>
</ul>

<h3 class="mt-4">Conclusão</h3>
<p>Se você enfrenta um caso de suspeita de envenenamento onde o animal já foi enterrado, a <strong>Toxicologia Forense</strong>, aliada à <strong>Patologia</strong>, pode buscar as evidências necessárias para fundamentar o nexo causal.</p>',
                'published_at' => now(),
            ]
        );

        // Seed second article (Orientation on expert terms)
        Post::updateOrCreate(
            ['slug' => 'diferenca-pericia-assistencia-tecnica-laudo-veterinario'],
            [
                'title' => 'Perícia, Assistência Técnica e Laudo Veterinário: Entenda as Diferenças',
                'summary' => 'Você sabe qual a diferença entre Perícia Judicial, Assistência Técnica e Parecer Técnico? Entenda o papel de cada serviço e saiba exatamente o que solicitar para o seu caso.',
                'category' => 'Assistência Técnica',
                'image' => 'assets/hero-bg.jpg',
                'author_id' => $user->id,
                'content' => '<p class="lead">Quando ocorre um incidente com um animal de estimação ou de produção (como morte suspeita, erro de procedimento clínico, reação adversa a vacinas ou maus-tratos), tutores e advogados frequentemente buscam auxílio pericial sem saber exatamente qual a modalidade técnica adequada para seu caso.</p>

<p>Na medicina veterinária legal e no ambiente jurídico, os termos <strong>Perícia Judicial</strong>, <strong>Assistência Técnica</strong>, <strong>Laudo Pericial</strong> e <strong>Parecer Técnico</strong> possuem significados e pesos processuais muito distintos. Entender essa nomenclatura é o primeiro passo para obter o resultado correto em juízo.</p>

<h3 class="mt-4">1. Perícia Judicial e o Laudo Pericial</h3>
<p>A <strong>Perícia Judicial</strong> ocorre quando um juiz determina que há necessidade de conhecimento técnico-científico que ele não possui. O juiz nomeia um profissional de sua confiança para atuar como perito daquela causa específica.</p>
<ul>
    <li><strong>Papel do Perito do Juízo:</strong> Ele é um auxiliar da Justiça, neutro e imparcial. Ele avalia as provas e responde às perguntas (quesitos) formuladas pelas partes do processo.</li>
    <li><strong>O Laudo Pericial:</strong> É o documento oficial redigido por este perito nomeado pelo juiz. O laudo pericial é anexado ao processo e serve de embasamento direto para a sentença.</li>
</ul>

<h3 class="mt-4">2. Assistência Técnica e o Parecer Técnico</h3>
<p>A <strong>Assistência Técnica</strong> é a contratação particular de um especialista veterinário forense por uma das partes envolvidas (o autor da ação ou o réu, como a clínica veterinária acusada).</p>
<ul>
    <li><strong>Papel do Assistente Técnico:</strong> Ele atua na defesa dos interesses de quem o contratou. O assistente formula os quesitos periciais estratégicos, acompanha fisicamente as perícias (como necropsias e exumações) e garante que os produtos e protocolos científicos sejam seguidos à risca.</li>
    <li><strong>O Parecer Técnico:</strong> É a peça escrita pelo assistente técnico. Diferente do Laudo, o Parecer Técnico contesta ou concorda de forma cientificamente fundamentada com o Laudo do perito do juiz, apontando eventuais falhas metodológicas.</li>
</ul>

<h3 class="mt-4">3. Análise de Viabilidade Técnica (Pré-Processual)</h3>
<p>Muitas vezes, antes mesmo de propor uma ação judicial por erro veterinário ou intoxicação, é indispensável realizar uma <strong>auditoria prévia de viabilidade técnica</strong>. Nesta análise, a nossa equipe audita os prontuários, receitas e exames do animal para responder à pergunta crucial: <em>Há base científica e nexo causal para prosseguir com um processo?</em> Isso evita litígios inviáveis ou sem provas.</p>

<blockquote class="blockquote my-4 p-3 bg-light border-start border-4 border-warning">
    <strong>Resumo Prático:</strong> O perito do juiz é nomeado pelo tribunal e emite o <strong>Laudo</strong>. O assistente técnico é contratado pelas partes e emite o <strong>Parecer Técnico</strong>.
</blockquote>

<h3 class="mt-4">Qual Serviço Você Precisa?</h3>
<p>Se você tem dúvidas sobre qual serviço é o indicado para o seu caso ou precisa de um parecer técnico, a <strong>MedVetLegal</strong> realiza exames periciais sob a coordenação da <strong>Dra. Adriana de Siqueira</strong>. Entre em contato preenchendo o formulário em nossa página principal.</p>',
                'published_at' => now(),
            ]
        );
    }
}